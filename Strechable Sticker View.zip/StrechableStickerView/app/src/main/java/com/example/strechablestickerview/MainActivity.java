package com.example.strechablestickerview;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.RelativeLayout;

import com.example.strechablestickerview.stickerview.ImageSticker;
import com.example.strechablestickerview.stickerview.StickerViews;

import java.io.IOException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    int w, h;
    private StickerViews mCurrentView;
    public ArrayList<Bitmap> BitArray = null;
    public ArrayList<Bitmap> BitmapArray = null;
    private ArrayList<View> mViews = new ArrayList<View>();
    ArrayList<StickerViews> stickerList = new ArrayList<StickerViews>();
    RelativeLayout flEditor;


    Drawable drawable;



    ImageSticker mCurrentView11;
    public ImageSticker imageSticker2 = null;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        DisplayMetrics om = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(om);
        h = om.heightPixels;
        w = om.widthPixels;
        Utils.width = w;
        Utils.height = h;
        BitmapArray = new ArrayList<Bitmap>();
        BitArray = new ArrayList<Bitmap>();
        flEditor = (RelativeLayout) findViewById(R.id.fl_Editor);
         drawable = getResources().getDrawable(R.drawable.sample);

        //simple sticeker view
        addStickerView(drawableToBitmap(drawable));

        //streched

        addMySticker();

    }

    public void addMySticker() {
        final ImageSticker imageSticker = new ImageSticker(getApplicationContext(), drawableToBitmap(drawable));
//        StringBuilder sb = new StringBuilder();
//        sb.append("nn");
//        sb.append(str.split("/")[1]);
//        Log.d("qqqqqqqqq", sb.toString());
//

        setCurrentEdit11(imageSticker);
        imageSticker2 = imageSticker;
        stickerOperations(imageSticker);
        //this.stickHair.setColorFilter(ContextCompat.getColor(getApplicationContext(), R.color.colorAccent));
        flEditor.addView(imageSticker);
        imageSticker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                disableall11();
                imageSticker.visiball();
                imageSticker2 = imageSticker;
            }
        });
        //flEditor.bringToFront();
    }
    public static Bitmap getbitmapfromsticker(Context context, String str) {
        try {
            return BitmapFactory.decodeStream(context.getAssets().open(str));
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public void setCurrentEdit11(ImageSticker imageSticker2) {
        this.mCurrentView11 = imageSticker2;
    }
    public void stickerOperations(final ImageSticker imageSticker1) {
        imageSticker1.setOperationListener(new ImageSticker.OperationListener() {
            @SuppressLint("WrongConstant")
            public void onDeleteClick() {
                imageSticker2 = null;
            }
        });
    }
    public void disableall11() {
        for (int i = 0; i < this.flEditor.getChildCount(); i++) {
            if (this.flEditor.getChildAt(i) instanceof ImageSticker) {
                ((ImageSticker) this.flEditor.getChildAt(i)).disableAll();
            }
        }
    }














    public Bitmap drawableToBitmap(Drawable drawable) {
        if (drawable instanceof BitmapDrawable) {
            return ((BitmapDrawable) drawable).getBitmap();
        }

        int width = drawable.getIntrinsicWidth();
        int height = drawable.getIntrinsicHeight();

        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);

        return bitmap;
    }

    private void addStickerView(Bitmap bits) {
        final StickerViews stickerView = new StickerViews(this);


        stickerView.setBitmap(bits);

        stickerView.setOperationListener(new StickerViews.OperationListener() {
            @Override
            public void onDeleteClick() {

                //Toast.makeText(getApplicationContext(), ""+mViews.indexOf(stickerView) + BitArray.size(),2000).show();
                BitArray.remove(mViews.indexOf(stickerView));

                mViews.remove(stickerView);
                flEditor.removeView(stickerView);

            }

            @Override
            public void onEdit(StickerViews stickerView) {
                mCurrentView.setInEdit(false);
                mCurrentView = stickerView;
                mCurrentView.setInEdit(true);
            }

            @Override
            public void onTop(StickerViews stickerView) {
                int position = mViews.indexOf(stickerView);
                if (position == mViews.size() - 1) {


                    return;
                }

                StickerViews stickerTemp = (StickerViews) mViews
                        .remove(position);
                mViews.add(mViews.size(), stickerTemp);
            }
        });
        RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT,
                RelativeLayout.LayoutParams.MATCH_PARENT);
        flEditor.addView(stickerView, lp);
        mViews.add(stickerView);
        setCurrentEdit(stickerView);




        stickerList.add(mCurrentView);
    }
    private void setCurrentEdit(StickerViews stickerView) {
        if (mCurrentView != null) {
            mCurrentView.setInEdit(false);
        }
        mCurrentView = stickerView;
        stickerView.setInEdit(true);
    }
}