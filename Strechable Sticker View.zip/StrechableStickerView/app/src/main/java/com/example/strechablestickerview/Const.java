package com.example.strechablestickerview;

import android.content.res.Resources;

public class Const {
    public static int dpToPx(int i) {
        return (int) (((float) i) * Resources.getSystem().getDisplayMetrics().density);
    }

    public static int pxToDp(int i) {
        return i / (Resources.getSystem().getDisplayMetrics().densityDpi / 160);
    }

    public static int getScreenWidth() {
        return Resources.getSystem().getDisplayMetrics().widthPixels;
    }

    public static int getScreenHeight() {
        return Resources.getSystem().getDisplayMetrics().heightPixels;
    }

}
