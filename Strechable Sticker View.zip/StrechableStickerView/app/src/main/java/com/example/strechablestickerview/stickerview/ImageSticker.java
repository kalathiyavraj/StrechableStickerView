package com.example.strechablestickerview.stickerview;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.ColorMatrixColorFilter;
import android.view.GestureDetector;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.example.strechablestickerview.Const;
import com.example.strechablestickerview.R;
import com.example.strechablestickerview.Utils;


@SuppressLint({"ViewConstructor"})
public class ImageSticker extends RelativeLayout {
    String StickerPath;
    int baseh;
    int basew;
    int basex;
    int basey;
    RelativeLayout btnXScale1;
    RelativeLayout btnXScale2;
    RelativeLayout btnYScale1;
    RelativeLayout btnYScale2;
    ImageView btndel;
    ImageView btnrot;
    ImageView btnscl;
    Context cntx;
    boolean freeze = false;

     int f102i;
    ImageView image;
    int imageID;
    ImageView imgring;
    RelativeLayout layBg;
    public RelativeLayout layGroup;
    public LayoutParams layoutParams;
    public LayoutInflater mInflater;
    Bitmap mainBitmap;
    int marb;
    int margl;
    int margt;
    int marr;
    public OperationListener operationListener;
     int pivx;
    int pivy;
    Bitmap resultBitmap;
    String sColor;
    float startDegree;


    public interface OperationListener {
        void onDeleteClick();
    }

    @SuppressLint({"WrongConstant", "ClickableViewAccessibility"})
    public ImageSticker(Context context, Bitmap bitmap) {
        super(context);
        this.cntx = context;
        this.layGroup = this;
        this.basex = 0;
        this.basey = 0;
        this.pivx = 0;
        this.pivy = 0;
        this.mInflater = (LayoutInflater) context.getSystemService("layout_inflater");
        this.mInflater.inflate(R.layout.image_sticker, this, true);
        this.btndel = (ImageView) findViewById(R.id.del);
        this.btnrot = (ImageView) findViewById(R.id.rotate);
        this.btnscl = (ImageView) findViewById(R.id.sacle);
        this.imgring = (ImageView) findViewById(R.id.image);
        this.btnXScale1 = (RelativeLayout) findViewById(R.id.h_scale);
        this.btnYScale1 = (RelativeLayout) findViewById(R.id.v_scale);
        this.btnXScale2 = (RelativeLayout) findViewById(R.id.h_scale2);
        this.btnYScale2 = (RelativeLayout) findViewById(R.id.v_scale2);
        //this.layoutParams = new LayoutParams(Const.dpToPx(120), Const.dpToPx((bitmap.getHeight() * 120) / bitmap.getWidth()));
        this.layoutParams = new LayoutParams(Const.dpToPx(120), Const.dpToPx((bitmap.getHeight() * 120) / bitmap.getWidth()));
        layoutParams.leftMargin = (Utils.width-250)/2;
        layoutParams.topMargin = (Utils.width-200)/2;
        layoutParams.alignWithParent=true;
        this.layGroup.setLayoutParams(this.layoutParams);
        this.image = (ImageView) findViewById(R.id.clipart);
        this.mainBitmap = bitmap;
        this.image.setImageBitmap(this.mainBitmap);
        this.image.setTag(Integer.valueOf(0));
        setOnTouchListener(new OnTouchListener() {
            final GestureDetector gestureDetector = new GestureDetector(ImageSticker.this.cntx, new SimpleOnGestureListener() {
                public boolean onDoubleTap(MotionEvent motionEvent) {
                    return false;
                }
            });

            public boolean onTouch(View view, MotionEvent motionEvent) {
                ImageSticker.this.visiball();
                if (ImageSticker.this.freeze) {
                    return true;
                }
                int action = motionEvent.getAction();
                if (action == 0) {
                    ImageSticker.this.layGroup.invalidate();
                    this.gestureDetector.onTouchEvent(motionEvent);
                    ImageSticker.this.layGroup.bringToFront();
                    ImageSticker.this.layGroup.performClick();
                    ImageSticker.this.basex = (int) (motionEvent.getRawX() - ((float) ImageSticker.this.layoutParams.leftMargin));
                    ImageSticker.this.basey = (int) (motionEvent.getRawY() - ((float) ImageSticker.this.layoutParams.topMargin));
                } else if (action == 2) {
                    int rawX = (int) motionEvent.getRawX();
                    int rawY = (int) motionEvent.getRawY();
                    ImageSticker imageSticker = ImageSticker.this;
                    imageSticker.layBg = (RelativeLayout) imageSticker.getParent();
                    if (rawX - ImageSticker.this.basex > (-((ImageSticker.this.layGroup.getWidth() * 2) / 3)) && rawX - ImageSticker.this.basex < ImageSticker.this.layBg.getWidth() - (ImageSticker.this.layGroup.getWidth() / 3)) {
                        ImageSticker.this.layoutParams.leftMargin = rawX - ImageSticker.this.basex;
                    }
                    if (rawY - ImageSticker.this.basey > (-((ImageSticker.this.layGroup.getHeight() * 2) / 3)) && rawY - ImageSticker.this.basey < ImageSticker.this.layBg.getHeight() - (ImageSticker.this.layGroup.getHeight() / 3)) {
                        ImageSticker.this.layoutParams.topMargin = rawY - ImageSticker.this.basey;
                    }
                    ImageSticker.this.layoutParams.rightMargin = -9999999;
                    ImageSticker.this.layoutParams.bottomMargin = -9999999;
                    ImageSticker.this.layGroup.setLayoutParams(ImageSticker.this.layoutParams);
                }
                return true;
            }
        });
        this.btnscl.setOnTouchListener(new OnTouchListener() {
            @SuppressLint({"NewApi"})
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (ImageSticker.this.freeze) {
                    return ImageSticker.this.freeze;
                }
                int rawX = (int) motionEvent.getRawX();
                int rawY = (int) motionEvent.getRawY();
                ImageSticker imageSticker = ImageSticker.this;
                imageSticker.layoutParams = (LayoutParams) imageSticker.layGroup.getLayoutParams();
                int action = motionEvent.getAction();
                if (action == 0) {
                    ImageSticker.this.layGroup.invalidate();
                    ImageSticker imageSticker2 = ImageSticker.this;
                    imageSticker2.basex = rawX;
                    imageSticker2.basey = rawY;
                    imageSticker2.basew = imageSticker2.layGroup.getWidth();
                    ImageSticker imageSticker3 = ImageSticker.this;
                    imageSticker3.baseh = imageSticker3.layGroup.getHeight();
                    ImageSticker.this.layGroup.getLocationOnScreen(new int[2]);
                    ImageSticker imageSticker4 = ImageSticker.this;
                    imageSticker4.margl = imageSticker4.layoutParams.leftMargin;
                    ImageSticker imageSticker5 = ImageSticker.this;
                    imageSticker5.margt = imageSticker5.layoutParams.topMargin;
                    ImageSticker imageSticker6 = ImageSticker.this;
                    imageSticker6.marr = imageSticker6.layoutParams.rightMargin;
                    ImageSticker imageSticker7 = ImageSticker.this;
                    imageSticker7.marb = imageSticker7.layoutParams.bottomMargin;
                } else if (action == 2) {
                    float degrees = (float) Math.toDegrees(Math.atan2((double) (rawY - ImageSticker.this.basey), (double) (rawX - ImageSticker.this.basex)));
                    if (degrees < 0.0f) {
                        degrees += 360.0f;
                    }
                    int i = rawX - ImageSticker.this.basex;
                    int i2 = rawY - ImageSticker.this.basey;
                    int i3 = i2 * i2;
                    int sqrt = (int) (Math.sqrt((double) ((i * i) + i3)) * Math.cos(Math.toRadians((double) (degrees - ImageSticker.this.layGroup.getRotation()))));
                    int sqrt2 = (int) (Math.sqrt((double) ((sqrt * sqrt) + i3)) * Math.sin(Math.toRadians((double) (degrees - ImageSticker.this.layGroup.getRotation()))));
                    int i4 = sqrt2 * 2;
                    int i5 = ImageSticker.this.basew + i4;
                    int i6 = i4 + ImageSticker.this.baseh;
                    if (i5 > 150) {
                        ImageSticker.this.layoutParams.width = i5;
                        ImageSticker.this.layoutParams.leftMargin = ImageSticker.this.margl - sqrt2;
                    }
                    if (i6 > 150) {
                        ImageSticker.this.layoutParams.height = i6;
                        ImageSticker.this.layoutParams.topMargin = ImageSticker.this.margt - sqrt2;
                    }
                    ImageSticker.this.layGroup.setLayoutParams(ImageSticker.this.layoutParams);
                    ImageSticker.this.layGroup.performLongClick();
                }
                return true;
            }
        });
        this.btnrot.setOnTouchListener(new OnTouchListener() {
            @SuppressLint({"NewApi"})
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (ImageSticker.this.freeze) {
                    return ImageSticker.this.freeze;
                }
                ImageSticker imageSticker = ImageSticker.this;
                imageSticker.layoutParams = (LayoutParams) imageSticker.layGroup.getLayoutParams();
                ImageSticker imageSticker2 = ImageSticker.this;
                imageSticker2.layBg = (RelativeLayout) imageSticker2.getParent();
                int[] iArr = new int[2];
                ImageSticker.this.layBg.getLocationOnScreen(iArr);
                int rawX = ((int) motionEvent.getRawX()) - iArr[0];
                int rawY = ((int) motionEvent.getRawY()) - iArr[1];
                int action = motionEvent.getAction();
                if (action == 0) {
                    ImageSticker.this.layGroup.invalidate();
                    ImageSticker imageSticker3 = ImageSticker.this;
                    imageSticker3.startDegree = imageSticker3.layGroup.getRotation();
                    ImageSticker imageSticker4 = ImageSticker.this;
                    imageSticker4.pivx = imageSticker4.layoutParams.leftMargin + (ImageSticker.this.getWidth() / 2);
                    ImageSticker imageSticker5 = ImageSticker.this;
                    imageSticker5.pivy = imageSticker5.layoutParams.topMargin + (ImageSticker.this.getHeight() / 2);
                    ImageSticker imageSticker6 = ImageSticker.this;
                    imageSticker6.basex = rawX - imageSticker6.pivx;
                    ImageSticker imageSticker7 = ImageSticker.this;
                    imageSticker7.basey = imageSticker7.pivy - rawY;
                } else if (action == 2) {
                    int i = ImageSticker.this.pivx;
                    int degrees = (int) (Math.toDegrees(Math.atan2((double) ImageSticker.this.basey, (double) ImageSticker.this.basex)) - Math.toDegrees(Math.atan2((double) (ImageSticker.this.pivy - rawY), (double) (rawX - i))));
                    if (degrees < 0) {
                        degrees += 360;
                    }
                    ImageSticker.this.layGroup.setRotation((ImageSticker.this.startDegree + ((float) degrees)) % 360.0f);
                }
                return true;
            }
        });
        this.btndel.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (!ImageSticker.this.freeze) {
                    ImageSticker imageSticker = ImageSticker.this;
                    imageSticker.layBg = (RelativeLayout) imageSticker.getParent();
                    ImageSticker.this.layBg.performClick();
                    ImageSticker.this.layBg.removeView(ImageSticker.this.layGroup);
                    if (ImageSticker.this.operationListener != null) {
                        ImageSticker.this.operationListener.onDeleteClick();
                    }
                }
            }
        });
        this.btnXScale1.setOnTouchListener(new OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (ImageSticker.this.freeze) {
                    return ImageSticker.this.freeze;
                }
                int rawX = (int) motionEvent.getRawX();
                int rawY = (int) motionEvent.getRawY();
                ImageSticker imageSticker = ImageSticker.this;
                imageSticker.layoutParams = (LayoutParams) imageSticker.layGroup.getLayoutParams();
                int action = motionEvent.getAction();
                if (action == 0) {
                    ImageSticker.this.layGroup.invalidate();
                    ImageSticker imageSticker2 = ImageSticker.this;
                    imageSticker2.basex = rawX;
                    imageSticker2.basey = rawY;
                    imageSticker2.basew = imageSticker2.layGroup.getWidth();
                    ImageSticker imageSticker3 = ImageSticker.this;
                    imageSticker3.baseh = imageSticker3.layGroup.getHeight();
                    ImageSticker.this.layGroup.getLocationOnScreen(new int[2]);
                    ImageSticker imageSticker4 = ImageSticker.this;
                    imageSticker4.margl = imageSticker4.layoutParams.leftMargin;
                    ImageSticker imageSticker5 = ImageSticker.this;
                    imageSticker5.margt = imageSticker5.layoutParams.topMargin;
                    ImageSticker imageSticker6 = ImageSticker.this;
                    imageSticker6.marr = imageSticker6.layoutParams.rightMargin;
                    ImageSticker imageSticker7 = ImageSticker.this;
                    imageSticker7.marb = imageSticker7.layoutParams.bottomMargin;
                } else if (action == 2) {
                    float degrees = (float) Math.toDegrees(Math.atan2((double) (rawY - ImageSticker.this.basey), (double) (rawX - ImageSticker.this.basex)));
                    if (degrees < 0.0f) {
                        degrees += 360.0f;
                    }
                    int i = rawX - ImageSticker.this.basex;
                    int i2 = rawY - ImageSticker.this.basey;
                    int i3 = i2 * i2;
                    int sqrt = (int) (Math.sqrt((double) ((i * i) + i3)) * Math.cos(Math.toRadians((double) (degrees - ImageSticker.this.layGroup.getRotation()))));
                    Math.sqrt((double) ((sqrt * sqrt) + i3));
                    Math.sin(Math.toRadians((double) (degrees - ImageSticker.this.layGroup.getRotation())));
                    int i4 = (sqrt * 2) + ImageSticker.this.basew;
                    if (i4 > 150) {
                        ImageSticker.this.layoutParams.width = i4 - sqrt;
                    }
                    ImageSticker.this.layGroup.setLayoutParams(ImageSticker.this.layoutParams);
                    ImageSticker.this.layGroup.performLongClick();
                }
                return true;
            }
        });
        this.btnYScale1.setOnTouchListener(new OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (ImageSticker.this.freeze) {
                    return ImageSticker.this.freeze;
                }
                int rawX = (int) motionEvent.getRawX();
                int rawY = (int) motionEvent.getRawY();
                ImageSticker imageSticker = ImageSticker.this;
                imageSticker.layoutParams = (LayoutParams) imageSticker.layGroup.getLayoutParams();
                int action = motionEvent.getAction();
                if (action == 0) {
                    ImageSticker.this.layGroup.invalidate();
                    ImageSticker imageSticker2 = ImageSticker.this;
                    imageSticker2.basex = rawX;
                    imageSticker2.basey = rawY;
                    imageSticker2.basew = imageSticker2.layGroup.getWidth();
                    ImageSticker imageSticker3 = ImageSticker.this;
                    imageSticker3.baseh = imageSticker3.layGroup.getHeight();
                    ImageSticker.this.layGroup.getLocationOnScreen(new int[2]);
                    ImageSticker imageSticker4 = ImageSticker.this;
                    imageSticker4.margl = imageSticker4.layoutParams.leftMargin;
                    ImageSticker imageSticker5 = ImageSticker.this;
                    imageSticker5.margt = imageSticker5.layoutParams.topMargin;
                    ImageSticker imageSticker6 = ImageSticker.this;
                    imageSticker6.marr = imageSticker6.layoutParams.rightMargin;
                    ImageSticker imageSticker7 = ImageSticker.this;
                    imageSticker7.marb = imageSticker7.layoutParams.bottomMargin;
                } else if (action == 2) {
                    float degrees = (float) Math.toDegrees(Math.atan2((double) (rawY - ImageSticker.this.basey), (double) (rawX - ImageSticker.this.basex)));
                    if (degrees < 0.0f) {
                        degrees += 360.0f;
                    }
                    int i = rawX - ImageSticker.this.basex;
                    int i2 = rawY - ImageSticker.this.basey;
                    int i3 = i2 * i2;
                    int sqrt = (int) (Math.sqrt((double) ((i * i) + i3)) * Math.cos(Math.toRadians((double) (degrees - ImageSticker.this.layGroup.getRotation()))));
                    int sqrt2 = (int) (Math.sqrt((double) ((sqrt * sqrt) + i3)) * Math.sin(Math.toRadians((double) (degrees - ImageSticker.this.layGroup.getRotation()))));
                    int i4 = (sqrt2 * 2) + ImageSticker.this.baseh;
                    if (i4 > 150) {
                        ImageSticker.this.layoutParams.height = i4 - sqrt2;
                    }
                    ImageSticker.this.layGroup.setLayoutParams(ImageSticker.this.layoutParams);
                    ImageSticker.this.layGroup.performLongClick();
                }
                return true;
            }
        });
        this.btnXScale2.setOnTouchListener(new OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (ImageSticker.this.freeze) {
                    return ImageSticker.this.freeze;
                }
                int i = -((int) motionEvent.getRawX());
                int i2 = -((int) motionEvent.getRawY());
                ImageSticker imageSticker = ImageSticker.this;
                imageSticker.layoutParams = (LayoutParams) imageSticker.layGroup.getLayoutParams();
                int action = motionEvent.getAction();
                if (action == 0) {
                    ImageSticker.this.layGroup.invalidate();
                    ImageSticker imageSticker2 = ImageSticker.this;
                    imageSticker2.basex = i;
                    imageSticker2.basey = i2;
                    imageSticker2.basew = imageSticker2.layGroup.getWidth();
                    ImageSticker imageSticker3 = ImageSticker.this;
                    imageSticker3.baseh = imageSticker3.layGroup.getHeight();
                    ImageSticker.this.layGroup.getLocationOnScreen(new int[2]);
                    ImageSticker imageSticker4 = ImageSticker.this;
                    imageSticker4.margl = imageSticker4.layoutParams.leftMargin;
                    ImageSticker imageSticker5 = ImageSticker.this;
                    imageSticker5.margt = imageSticker5.layoutParams.topMargin;
                    ImageSticker imageSticker6 = ImageSticker.this;
                    imageSticker6.marr = imageSticker6.layoutParams.rightMargin;
                    ImageSticker imageSticker7 = ImageSticker.this;
                    imageSticker7.marb = imageSticker7.layoutParams.bottomMargin;
                } else if (action == 2) {
                    float degrees = (float) Math.toDegrees(Math.atan2((double) (i2 - ImageSticker.this.basey), (double) (i - ImageSticker.this.basex)));
                    if (degrees < 0.0f) {
                        degrees += 360.0f;
                    }
                    int i3 = i - ImageSticker.this.basex;
                    int i4 = i2 - ImageSticker.this.basey;
                    int i5 = i4 * i4;
                    int sqrt = (int) (Math.sqrt((double) ((i3 * i3) + i5)) * Math.cos(Math.toRadians((double) (degrees - ImageSticker.this.layGroup.getRotation()))));
                    Math.sqrt((double) ((sqrt * sqrt) + i5));
                    Math.sin(Math.toRadians((double) (degrees - ImageSticker.this.layGroup.getRotation())));
                    int i6 = (sqrt * 2) + ImageSticker.this.basew;
                    if (i6 > 150) {
                        ImageSticker.this.layoutParams.width = i6 - sqrt;
                        ImageSticker.this.layoutParams.leftMargin = ImageSticker.this.margl - sqrt;
                        ImageSticker.this.layoutParams.rightMargin = ImageSticker.this.marr;
                    }
                    ImageSticker.this.layGroup.setLayoutParams(ImageSticker.this.layoutParams);
                    ImageSticker.this.layGroup.performLongClick();
                }
                return true;
            }
        });
        this.btnYScale2.setOnTouchListener(new OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (ImageSticker.this.freeze) {
                    return ImageSticker.this.freeze;
                }
                int i = -((int) motionEvent.getRawX());
                int i2 = -((int) motionEvent.getRawY());
                ImageSticker imageSticker = ImageSticker.this;
                imageSticker.layoutParams = (LayoutParams) imageSticker.layGroup.getLayoutParams();
                int action = motionEvent.getAction();
                if (action == 0) {
                    ImageSticker.this.layGroup.invalidate();
                    ImageSticker imageSticker2 = ImageSticker.this;
                    imageSticker2.basex = i;
                    imageSticker2.basey = i2;
                    imageSticker2.basew = imageSticker2.layGroup.getWidth();
                    ImageSticker imageSticker3 = ImageSticker.this;
                    imageSticker3.baseh = imageSticker3.layGroup.getHeight();
                    ImageSticker.this.layGroup.getLocationOnScreen(new int[2]);
                    ImageSticker imageSticker4 = ImageSticker.this;
                    imageSticker4.margl = imageSticker4.layoutParams.leftMargin;
                    ImageSticker imageSticker5 = ImageSticker.this;
                    imageSticker5.margt = imageSticker5.layoutParams.topMargin;
                    ImageSticker imageSticker6 = ImageSticker.this;
                    imageSticker6.marr = imageSticker6.layoutParams.rightMargin;
                    ImageSticker imageSticker7 = ImageSticker.this;
                    imageSticker7.marb = imageSticker7.layoutParams.bottomMargin;
                } else if (action == 2) {
                    float degrees = (float) Math.toDegrees(Math.atan2((double) (i2 - ImageSticker.this.basey), (double) (i - ImageSticker.this.basex)));
                    if (degrees < 0.0f) {
                        degrees += 360.0f;
                    }
                    int i3 = i - ImageSticker.this.basex;
                    int i4 = i2 - ImageSticker.this.basey;
                    int i5 = i4 * i4;
                    int sqrt = (int) (Math.sqrt((double) ((i3 * i3) + i5)) * Math.cos(Math.toRadians((double) (degrees - ImageSticker.this.layGroup.getRotation()))));
                    int sqrt2 = (int) (Math.sqrt((double) ((sqrt * sqrt) + i5)) * Math.sin(Math.toRadians((double) (degrees - ImageSticker.this.layGroup.getRotation()))));
                    int i6 = (sqrt2 * 2) + ImageSticker.this.baseh;
                    if (i6 > 150) {
                        ImageSticker.this.layoutParams.height = i6 - sqrt2;
                        ImageSticker.this.layoutParams.topMargin = ImageSticker.this.margt - sqrt2;
                        ImageSticker.this.layoutParams.bottomMargin = ImageSticker.this.marb;
                    }
                    ImageSticker.this.layGroup.setLayoutParams(ImageSticker.this.layoutParams);
                    ImageSticker.this.layGroup.performLongClick();
                }
                return true;
            }
        });
    }

    @SuppressLint("WrongConstant")
    public void disableAll() {
        this.btndel.setVisibility(4);
        this.btnrot.setVisibility(4);
        this.btnscl.setVisibility(4);
        this.imgring.setVisibility(4);
        this.btnXScale1.setVisibility(4);
        this.btnYScale1.setVisibility(4);
        this.btnXScale2.setVisibility(4);
        this.btnYScale2.setVisibility(4);
    }

    public ImageView getImageView() {
        return this.image;
    }

    public float getOpacity() {
        return this.image.getAlpha();
    }

    public void setOpacity(float f) {
        this.image.setAlpha(f);
    }



    public void setColor(int i) {
        this.image.getDrawable().setColorFilter(null);
        this.image.getDrawable().setColorFilter(new ColorMatrixColorFilter(new float[]{0.33f, 0.33f, 0.33f, 0.0f, (float) Color.red(i), 0.33f, 0.33f, 0.33f, 0.0f, (float) Color.green(i), 0.33f, 0.33f, 0.33f, 0.0f, (float) Color.blue(i), 0.0f, 0.0f, 0.0f, 1.0f, 0.0f}));
        this.image.setTag(Integer.valueOf(i));
        this.layGroup.performLongClick();
    }

    public void setFreeze(boolean z) {
        this.freeze = z;
    }






    @SuppressLint("WrongConstant")
    public void visiball() {
        this.btndel.setVisibility(0);
        this.btnrot.setVisibility(0);
        this.btnscl.setVisibility(0);
        this.imgring.setVisibility(0);
        this.btnXScale1.setVisibility(0);
        this.btnXScale2.setVisibility(0);
        this.btnYScale2.setVisibility(0);
        this.btnYScale1.setVisibility(0);
    }






    public void setPath(String str) {
        this.StickerPath = str;
    }

    public String getPath() {
        return this.StickerPath;
    }



    public void delete() {
        if (!this.freeze) {
            this.layBg = (RelativeLayout) getParent();
            this.layBg.performClick();
            this.layBg.removeView(this.layGroup);
            OperationListener operationListener2 = this.operationListener;
            if (operationListener2 != null) {
                operationListener2.onDeleteClick();
            }
        }
    }

    public void setOperationListener(OperationListener operationListener2) {
        this.operationListener = operationListener2;
    }


}
