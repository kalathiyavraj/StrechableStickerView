package com.example.strechablestickerview.stickerview;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.media.ExifInterface;
import android.util.Log;

import com.example.strechablestickerview.Const;

import java.io.ByteArrayOutputStream;
import java.io.IOException;



public class ImageUtils {
    static Context context11;
    private static ImageUtils mInstant;
    private int kkMP;
    private int newHeight;
    private int newWidth;

    public static ImageUtils getInstant(Context context) {
        context11 = context;
        if (mInstant == null) {
            mInstant = new ImageUtils();
        }
        return mInstant;
    }

    public int getStatusBarHeight(Context context) {
        int identifier = context.getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (identifier > 0) {
            return context.getResources().getDimensionPixelSize(identifier);
        }
        return 0;
    }

    private void setNewMaster(int i, int i2) {
        int i3 = this.kkMP;
        this.newHeight = (i2 * i3) / 100;
        this.newWidth = (i3 * i) / 100;
    }

    private void adjustResultSize(Bitmap bitmap) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int screenHeight = Const.getScreenHeight() - Const.dpToPx(Const.pxToDp(getStatusBarHeight(context11)) + 128);
        int screenWidth = Const.getScreenWidth() - Const.dpToPx(20);
        int i = (screenHeight * 100) / height;
        this.kkMP = i;
        setNewMaster(width, height);
        if (this.newHeight > screenHeight) {
            this.kkMP = i;
            setNewMaster(width, height);
        } else if (this.newWidth > screenWidth) {
            this.kkMP = (screenWidth * 100) / width;
            setNewMaster(width, height);
        }
        StringBuilder sb = new StringBuilder();
        sb.append(this.newWidth);
        sb.append("-");
        sb.append(this.newHeight);
        Log.d("loggingMyStkerPosition", sb.toString());
    }

    public Bitmap getScaledAndCompressedBitmap(String str) {
        Bitmap compressedBitmap = getCompressedBitmap(str);
        adjustResultSize(compressedBitmap);
        return Bitmap.createScaledBitmap(compressedBitmap, this.newWidth, this.newHeight, true);
    }

    public Bitmap getScaledBitmap(String str) {
        Bitmap decodeFile = BitmapFactory.decodeFile(str);
        adjustResultSize(decodeFile);
        return Bitmap.createScaledBitmap(decodeFile, this.newWidth, this.newHeight, true);
    }

    public Bitmap getScaledBitmap(Bitmap bitmap) {
        adjustResultSize(bitmap);
        return Bitmap.createScaledBitmap(bitmap, this.newWidth, this.newHeight, true);
    }

    public Bitmap getCompressedBitmap(String str) {
        Bitmap bitmap;
        float screenHeight = (float) Const.getScreenHeight();
        float screenWidth = (float) Const.getScreenWidth();
        Options options = new Options();
        options.inJustDecodeBounds = true;
        Bitmap decodeFile = BitmapFactory.decodeFile(str, options);
        int i = options.outHeight;
        int i2 = options.outWidth;
        StringBuilder sb = new StringBuilder();
        sb.append(i2);
        sb.append(" ");
        sb.append(i);
        Log.d("aaaaaa", sb.toString());
        float f = (float) i2;
        float f2 = (float) i;
        float f3 = f / f2;
        float f4 = screenWidth / screenHeight;
        if (f2 > screenHeight || f > screenWidth) {
            if (f3 < f4) {
                i2 = (int) ((screenHeight / f2) * f);
                i = (int) screenHeight;
            } else if (f3 > f4) {
                i = (int) ((screenWidth / f) * f2);
                i2 = (int) screenWidth;
            } else {
                i = (int) screenHeight;
                i2 = (int) screenWidth;
            }
        }
        options.inSampleSize = calculateInSampleSize(options, i2, i);
        options.inJustDecodeBounds = false;
        options.inTempStorage = new byte[16384];
        try {
            decodeFile = BitmapFactory.decodeFile(str, options);
        } catch (OutOfMemoryError e) {
            e.printStackTrace();
        }
        try {
            bitmap = Bitmap.createBitmap(i2, i, Config.ARGB_8888);
        } catch (OutOfMemoryError e2) {
            e2.printStackTrace();
            bitmap = null;
        }
        float f5 = (float) i2;
        float f6 = f5 / ((float) options.outWidth);
        float f7 = (float) i;
        float f8 = f7 / ((float) options.outHeight);
        float f9 = f5 / 2.0f;
        float f10 = f7 / 2.0f;
        Matrix matrix = new Matrix();
        matrix.setScale(f6, f8, f9, f10);
        Canvas canvas = new Canvas(bitmap);
        canvas.setMatrix(matrix);
        canvas.drawBitmap(decodeFile, f9 - (((float) decodeFile.getWidth()) / 2.0f), f10 - (((float) decodeFile.getHeight()) / 2.0f), new Paint(2));
        try {
            int attributeInt = new ExifInterface(str).getAttributeInt("Orientation", 0);
            Matrix matrix2 = new Matrix();
            if (attributeInt == 6) {
                matrix2.postRotate(90.0f);
            } else if (attributeInt == 3) {
                matrix2.postRotate(180.0f);
            } else if (attributeInt == 8) {
                matrix2.postRotate(270.0f);
            }
            bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix2, true);
        } catch (IOException e3) {
            e3.printStackTrace();
        }
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(CompressFormat.JPEG, 85, byteArrayOutputStream);
        byte[] byteArray = byteArrayOutputStream.toByteArray();
        Bitmap decodeByteArray = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
        StringBuilder sb2 = new StringBuilder();
        sb2.append(decodeByteArray.getWidth());
        sb2.append(" ");
        sb2.append(decodeByteArray.getHeight());
        Log.d("aaaaaa", sb2.toString());
        return decodeByteArray;
    }

    private int calculateInSampleSize(Options options, int i, int i2) {
        int i3;
        int i4 = options.outHeight;
        int i5 = options.outWidth;
        if (i4 > i2 || i5 > i) {
            i3 = Math.round(((float) i4) / ((float) i2));
            int round = Math.round(((float) i5) / ((float) i));
            if (i3 >= round) {
                i3 = round;
            }
        } else {
            i3 = 1;
        }
        while (((float) (i5 * i4)) / ((float) (i3 * i3)) > ((float) (i * i2 * 2))) {
            i3++;
        }
        return i3;
    }
}
