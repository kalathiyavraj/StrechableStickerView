package com.example.strechablestickerview;

public class Utils {
    public static  int width,height;

}
